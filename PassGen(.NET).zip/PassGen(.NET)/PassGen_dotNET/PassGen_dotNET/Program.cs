﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassGen_dotNET
{
    class Program
    {
        private static int[] generatedPassword;

        public static void Main(string[] args)
        {

            menu();
            /* passGen(Int32.Parse(Console.ReadLine()));
             Console.WriteLine(translate(generatedPassword));
             Console.ReadLine();
             */
        }

        private static void menu()
        {
            Console.WriteLine("--- WEOLCOME TO PASSGEN V_0.0.1 ---");
            Console.WriteLine("A PASSWORD UNDER 8 CHARACTERS AND ABOVE IS CONSIDERED SECURE ONE, HOWEVER IF YOU'D LIKE IT IS POSSIBLE TO GENERATE UNSECURE PASSWORDS");
        InsertPassword:
            Console.WriteLine("PLEASE INSERT HOW LONG YOU WANT YOUR PASSWORD TO BE");

            int lenght = Int32.Parse(Console.ReadLine());
            char selection;
            if (lenght <= 7 && lenght > 0)
            {
            InsecurePassWord:
                Console.WriteLine("WE'VE DETECTED YOU WANT TO GENERATE AN INSECURE PASSWORD, DO YOU WISH TO CONTINUE? Y/N");
                selection = Console.ReadLine()[0];
                if (selection == 'y' || selection == 'Y')
                {
                    Console.WriteLine("GENERATING PASSWORD, PLEASE WAIT...");
                    passGen(lenght);
                }
                else if (selection == 'n' || selection == 'N')
                    goto InsertPassword;
                else
                {
                    Console.WriteLine("INCORRECT INPUT");
                    goto InsecurePassWord;
                }

            }
            else
            {
            SecurePassWord:
                Console.WriteLine("YOU'VE SELECTED TO CREATE A SECURE PASSWORD WITH {0} CHARACTER, IS THIS CORRECT? Y/N", lenght);
                selection = Console.ReadLine()[0];
                if (selection == 'y' || selection == 'Y')
                {
                    Console.WriteLine("GENERATING PASSWORD, PLEASE WAIT...");
                    passGen(lenght);
                }
                else if (selection == 'n' || selection == 'N')
                    goto SecurePassWord;
                else
                {
                    Console.WriteLine("INCORRECT INPUT");
                    goto SecurePassWord;
                }


            }
            Console.WriteLine("PASSWORD SUCCESFULLY CREATED WITH {0} CHARACTERS: {1}", lenght, translate(generatedPassword));
            Console.ReadLine();

        }

        private static int[] passGen(int size)
        {
            generatedPassword = new int[size];
            Random r = new Random();
            for (int i = 0; i < size; i++)
                generatedPassword[i] = r.Next(33, 126);
            return generatedPassword;
        }

        private static String translate(int[] pass)
        {
            String fullPass = "";
            char convert;
            for (int i = 0; i < pass.Length; i++)
            {
                convert = (char)pass[i];
                fullPass += convert;
            }
            return fullPass;
        }
    }
}
